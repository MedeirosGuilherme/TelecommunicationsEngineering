package engtelecom.bcd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcdApplicationTests {

	@Test
	void contextLoads() {
	}

}
